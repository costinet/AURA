function [check] = VfwdIrev(obj)
%VfwdIrev This function checks to ensure the physical limitations of diodes
%are met in the circuit and correct swithcing invervals to find ZVS.
%   This has turned into the  main center to debug for Diode Conduction
%   adjustments

%     %%%%%%   %      %  %%%%%%%    %%%%%%
%    %      %  %      %  %      %  %      %
%    %      %  %      %  %      %  %      %
%    %%%%%%%%  %      %  %%%%%%%   %%%%%%%%
%    %      %  %      %  %%        %      %
%    %      %  %      %  % %       %      %
%    %      %  %      %  %  %      %      %
%    %      %  %      %  %   %     %      %
%    %      %   %    %   %    %    %      %
%    %      %    %%%%    %     %   %      %

%% Notes
% Determine if there is a violation of Reverse current or forward voltage
% in a diode:

% "For an ideal diode there should never be a reverse current." - Physics

% Remeber Representation of FET:

% Postive voltage and current from Drain to Source
%%% This is Cathode to Anode for the body diode!!!!

% Positive voltage and current from Anode to Cathode for Power diodes

%%%% Thus FET and Diode voltage and current are switched for diodes!!!!!

% Note: For a FET there can be a reverse current if the FET is ON


% Display Current Waveforms

% These are variables that are being tested to put in the simulation class
% or other classes to speed up the function
output_Cap_pos = 2; % Position of the output capacitor
Vo = 1.2; % Value of the output voltage

close all


counter = 0;
debug = true;
if debug
    StateNumbers = obj.Converter.Topology.Parser.StateNumbers;
    [xs, t, y] = obj.SS_WF_Reconstruct();
    % nattempts
    figure(1)
    ns = size(xs,1);
    for i=1:ns
        subplot(10*ns,1,i*10-9:i*10)
        hold on;
        plot(t,y(StateNumbers(i),:), 'Linewidth', 3);
        ylabel(obj.getstatenames{i})
        box on
        
        if(i<ns)
            set(gca, 'Xticklabel', []);
        else
            xlabel('t')
        end
    end
    
end
% while (counter<1) % only loop through diode stuff for now
counter = counter+1;
check = 0;
ron = .05;
As = obj.As;
Bs = obj.Bs;
Xs = obj.Xs;
u = obj.u;
ts = obj.ts;
Voerr = mean(Xs(output_Cap_pos,:)) - Vo;

% Variable Declaration:
Max_Diode_Reverse_Current = -0.005; % Negative for reverse current
Max_Diode_Forward_Voltage = 0.7; % Maximum Forward voltage of diode
Max_FET_Forward_Voltage = 0.5; % Maximum Forward voltage of diode in FET
Max_FET_Reverse_Current = 0.005; % Positive due to polarity of current measurement for FET diode

% Calculate the response of each time interval of the circuit
for i = 1:1:size(Xs,2)-1
    Y(:,:,i) = obj.Cs(:,:,i)*Xs(:,i+1)+obj.Ds(:,:,i)*u;
end

% Get measurement names and type of measurement Voltage (V) or Current (A)
[measurename,remain] = strtok(obj.Converter.Topology.Parser.OutputNamesCD(:,1));


%% Diode Current
% Find diode current measurement positions in C and D matrix
diode_current_pos = contains(measurename,'D') & contains(remain, ' A');

% Get diode current measurements for each time interval
Diode_current = Y.*diode_current_pos;

% Iterate through and check violation of reverse current in diode
for i = 1:1:size(Diode_current,3)
    violations = measurename(Diode_current(:,:,i)<Max_Diode_Reverse_Current,1);
    if ~isempty(violations)
        for j = 1:1:length(violations)
            fprintf('Reverse current violation of Diode %s at end of time interval %.0f \n', violations{j},i)
        end
        
    end
end


%% Diode Voltage
num = 0;
while num<5
% Find diode voltage measurement positions in C and D matrix
diode_voltage_pos = contains(measurename,'D') & contains(remain, ' V');

% Get diode voltage measurements for each time interval
Diode_voltage = Y.*diode_voltage_pos;


% Iterate through and check violation of forward voltage in diode
for i = 1:1:size(Diode_voltage,3)
    violations = measurename(Diode_voltage(:,:,i)>Max_Diode_Forward_Voltage,1); % Positive because diode voltage is reported at anode to cathode
    if ~isempty(violations)
        for j = 1:1:length(violations)
            fprintf('Forward voltage violation of Diode %s during time interval %.0f \n', violations{j},i)
        end
        
        % Assume violation means that period is too long if there are no
        % zero derivatives
        
        % Check for derivatives
        % Below
        
        % Check that slope is in right direction
        
        % Need to converter from Y to X position using char
        % Use parser.Stateposition???
        
        if sum(Diode_voltage(:,:,i)-Diode_voltage(:,:,i-1)>0)
            % Reduce time of period (assume liner slope)
            [tsnew, dxsdtd, hardSwNecessary_DT1] = obj.Baxter_adjustDiodeConduction(obj.Xs, i+1, 4, 5, 0, 1); % For now hard code Vin and Vout
            tsnew
            
            introduced_Voerr = sum(dxsdtd(output_Cap_pos,2:end).*(ts-tsnew));
            ts = tsnew;
            obj.ts = tsnew;
            obj.SS_Soln();
            obj.CorrectXs()
            [xs, t, y] = obj.SS_WF_Reconstruct();
            % nattempts
            figure(num+2)
            ns = size(xs,1);
            if i ==4
            for z=1:ns
                subplot(10*ns,1,z*10-9:z*10)
                hold on;
                plot(t,y(StateNumbers(z),:), 'Linewidth', 3);
                ylabel(obj.getstatenames{z})
                box on
                
                if(z<ns)
                    set(gca, 'Xticklabel', []);
                else
                    xlabel('t(s)')
                end
            end
            end
            % Determine output sensitivity to time 
            delta_DTs = max(min(ts)/10, sum(ts)/10000);
            obj.Baxter_StateSensitivity('ts', 1, delta_DTs,3);
            dXs = obj.Xs;
            dxsdt = (Xs - dXs)/delta_DTs;
            dt = (Voerr+introduced_Voerr)/mean(dxsdt(output_Cap_pos,:));
            
            if(ts(3) - dt <0)
                dt = ts(3);
            elseif(ts(1) + dt < 0)
                dt = -ts(1);
            end
            dt = dt*.5;
            dt
            ts(1) = ts(1) + dt;
            ts(3) = ts(3) - dt;
            
            obj.ts = ts;
            obj.SS_Soln();
            obj.CorrectXs;
            Xs = obj.Xs;
            Voerr = mean(Xs(output_Cap_pos,:)) - Vo;
        end
    end
    
end
num = num+1;
end
%end
%% FET Voltage
num = 0;
while num<5
% Find FET voltage measurement positions in C and D matrix
FET_voltage_pos = contains(measurename,'M2') & contains(remain, ' V');

% Get FET voltage measurements for each time interval
FET_voltage = Y.*FET_voltage_pos;

% Iterate through and check violation of forward voltage in FET body diode
for i = 1:1:size(FET_voltage,3)
    violations = measurename(FET_voltage(:,:,i)<-Max_FET_Forward_Voltage,1); % Because FET Voltage is given from drain to source (Cathode to Anode)
    if ~isempty(violations)
        for j = 1:1:length(violations)
            fprintf('Forward voltage violation of FET''s diode %s during time interval %.0f \n', violations{j},i)
        end
        
        
        %if sum(FET_voltage(:,:,i)-FET_voltage(:,:,i-1)>0)
            % Reduce time of period (assume liner slope)
            [tsnew, dxsdtd, hardSwNecessary_DT1] = obj.Baxter_adjustDiodeConduction(obj.Xs, i+1, 4, 5, 0, 1); % For now hard code Vin and Vout
            tsnew
            i
            introduced_Voerr = sum(dxsdtd(output_Cap_pos,2:end).*(ts-tsnew));
            ts = tsnew;
            obj.ts = tsnew;
            obj.SS_Soln();
            obj.CorrectXs()
            [xs, t, y] = obj.SS_WF_Reconstruct();
            % nattempts
            figure(num+2)
            ns = size(xs,1);
            if i ==4
            for z=1:ns
                subplot(10*ns,1,z*10-9:z*10)
                hold on;
                plot(t,y(StateNumbers(z),:), 'Linewidth', 3);
                ylabel(obj.getstatenames{z})
                box on
                
                if(z<ns)
                    set(gca, 'Xticklabel', []);
                else
                    xlabel('t(s)')
                end
            end
            end
            % Determine output sensitivity to time 
            delta_DTs = max(min(ts)/10, sum(ts)/10000);
            obj.Baxter_StateSensitivity('ts', 1, delta_DTs,3);
            dXs = obj.Xs;
            dxsdt = (Xs - dXs)/delta_DTs;
            dt = (Voerr+introduced_Voerr)/mean(dxsdt(output_Cap_pos,:));
            
            if(ts(3) - dt <0)
                dt = ts(3);
            elseif(ts(1) + dt < 0)
                dt = -ts(1);
            end
            dt = dt*.5;
            dt
            ts(1) = ts(1) + dt;
            ts(3) = ts(3) - dt;
            
            obj.ts = ts;
            obj.SS_Soln();
            obj.CorrectXs;
            Xs = obj.Xs;
            Voerr = mean(Xs(output_Cap_pos,:)) - Vo;
       %end
    end
end
num = num+1;
end

%% FET Current
ONorOFF = obj.Converter.Topology.Parser.ONorOFF;

% Find FET voltage measurement positions in C and D matrix
FET_current_pos = contains(measurename,'M') & contains(remain, ' A');

% Get FET voltage measurements for each time interval
FET_current = Y.*FET_current_pos;

% Iterate through and check violation of forward voltage in FET body diode

FET_Names = obj.Converter.Topology.Parser.StateNames(obj.Converter.Topology.Parser.DMpos(:,3)==1,1); % Get the name of FETs in the converter
[FET_names,~] = strtok(FET_Names,'_'); % Separate FET names from the '_C'
m = 0;
for k = 1:1:size(obj.Converter.Topology.Parser.DMpos,1) % Iterate through all state variables
    if obj.Converter.Topology.Parser.DMpos(k,3)==1 % If the index is a FET
        m = m+1; % Increment variable
        for i = 1:1:size(ONorOFF,2) % Iterate through all time intervals
            if ONorOFF(k,i) == -1 % If the FET is off during given time interval
                comparison = repmat(FET_names(m),size(measurename,1),1); % Use repmat to create copy of FET names that is equal in length to output names (Y)
                FET_current_pos = strcmp(measurename,comparison) & contains(remain, ' A'); % Compare chars to determine where the current measurement is for the given FET
                FET_current = Y.*FET_current_pos; % Solve for the measured value of the FET current
                violations = measurename(FET_current(:,:,i)>Max_FET_Reverse_Current,1); % Because FET Current is given from drain to source (Cathode to Anode)
                if ~isempty(violations)
                    for j = 1:1:length(violations)
                        fprintf('Reverse current violation of FET''s diode %s during time interval %.0f \n', violations{j},i)
                    end
                end
            end
            
        end
        
    end
end


%% Check to see if entering other state than the one listed in order

% Attempt at identifing fixing hard switching



global  I_solemnly_swear_that_I_am_up_to_no_good;

for i = 1:1:size(Xs,1) % Cycle through state variables
    for j = 2:1:size(Xs,2) % Cycle through time intervals
        j;% is time interval for Xss
        k = j-1; % k is time interval for everything else
        if ONorOFF(i,k) ~=0 % if FET or Diode
            
            Current_StateName = strsplit(obj.Converter.Topology.Parser.StateNames{i,1},'_'); % Separte
            Voltage_pos = strcmp(repmat(Current_StateName{1},10,1),measurename) & contains(remain, ' V'); % Find position of selected state variable voltage measurement
            Current_pos = strcmp(repmat(Current_StateName{1},10,1),measurename) & contains(remain, ' A'); % Find position of selected state variable current measurement
            Voltage = Y.*Voltage_pos; % Set Voltage of switching element
            Current = Y.*Current_pos; % Set Current of switching element
            %{
%             if k == 1
%                 DeltaV = Voltage(:,:,k)-Voltage(:,:,end);
%                 DeltaC = Current(:,:,k)-Current(:,:,end);
%                 StartDeriv=As(i,:,k)*Xs(:,j-1)+Bs(i,:,k)*u;
%                 EndDeriv=As(i,:,k)*Xs(:,j)+Bs(i,:,k)*u;
%             else
%                 DeltaV = Voltage(:,:,k)-Voltage(:,:,k-1);
%                 DeltaC = Current(:,:,k)-Current(:,:,k-1);
%                 StartDeriv=As(i,:,k)*Xs(:,j-1)+Bs(i,:,k)*u;
%                 EndDeriv=As(i,:,k)*Xs(:,j)+Bs(i,:,k)*u;
%             end
            
%             J = zeros(size(Xs,1),size(Xs,1));
%             J(i,i) = 1;
%             %  fun = @(t)((As(i,:,k)*expm(As(:,:,k).*t)*Xs(:,j)+expm(As(:,:,k).*t)*Bs(i,:,k)*u));
%
%             I_solemnly_swear_that_I_am_up_to_no_good = [i,j,k];
%             x0 = 4e-6;
%             A = [];
%             B = [];
%             Aeq = [];
%             Beq = [];
%             LB = 0;
%             UB = 5e-6;
%             fun = @(t) t;
%
%             options = optimoptions('fmincon','StepTolerance',1e-12,'ConstraintTolerance',1e-9);
%             if debug
%                 options = optimoptions('fmincon','Display','off','StepTolerance',1e-65,'ConstraintTolerance',1e-3,'OptimalityTolerance',1e-5);
%             end
%             tic
%             [X,FVAL,EXITFLAG,OUTPUT,LAMBDA,GRAD,HESSIAN] = fmincon(fun,x0,A,B,Aeq,Beq,LB,UB,@obj.zero,options);
%             toc
            % Plot dx/dt if debug
            
            %{
            % Create symbolic equation 0 = Ax+Bu (Not the best way to do this)
            eqn = zeros(size(Xs,1),1) == J*(As(:,:,k)*expm(As(:,:,k).*t)*Xs(:,j)+expm(As(:,:,k).*t)*Bs(:,:,k)*u);
            the_answer=vpasolve(eqn,t,[0 5e-9]); % numerically solve in given time interval
            disp(the_answer)

            clear the_answer
            %}
            
            %%% Attempt to find local max or min of voltage for diode %%%
            %  time = 0;
            %  data = [];
            %             for n = 100:1:200
            %             dxdt = As(:,:,k)*expm(As(:,:,k)*time)*Xs(:,j)+expm(As(:,:,k)*time)*Bs(:,:,k)*u;
            %             time = time+1/n*dxdt(i,1);
            %             data(end+1) = time;
            %             end
            %end
            %}
            if obj.Converter.Topology.Parser.DMpos(i,2)==1 % if diode
                
                if ONorOFF(i,k) == 1 % if diode ON
                    if sum(Voltage(:,:,k)) < 0
                        fprintf('Violation of %s in state %.0f \n',obj.Converter.Topology.Parser.StateNames{i,1},j-1)
                        
                    end
                elseif ONorOFF(i,j-1) == -1 % if diode off
                    if sum(Current(:,:,k)) > 0
                        fprintf('Violation of %s in state %.0f \n',obj.Converter.Topology.Parser.StateNames{i,1},j-1)
                    end
                else
                    fprintf('Messed up\n')
                end
            elseif obj.Converter.Topology.Parser.DMpos(i,3)==1 % if FET
                if ONorOFF(i,j-1) == 1 % if FET ON
                    if sum(Voltage(:,:,j-1)) < 0
                        % This doesn't matter if the FET is on
                        % Is already checked above
                        % Can have bidirectional voltage and current
                        % fprintf('Violation of %s in state %.0f \n',obj.StateNames{i,1},j-1)
                    end
                    
                elseif ONorOFF(i,j-1) == -1 % if FET off
                    if sum(Current(:,:,j-1)) > 0
                        fprintf('Violation of %s in state %.0f \n',obj.Converter.Topology.Parser.StateNames{i,1},j-1)
                    end
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    % Find if FET turns on next
                    if size(ONorOFF,2)+1 == j
                        if ONorOFF(i,2) == 1
                            if Voltage < -10*ron*2
                                fprintf('Hard swithcing for %s in time interval j\n',obj.Converter.Topology.Parser.StateNames{i,1},j-1)
                            end
                        end
                        
                    else
                        if ONorOFF(i,j) == 1
                            if Voltage < -10*ron*2
                                fprintf('Hard swithcing for %s in time interval j\n',obj.Converter.Topology.Parser.StateNames{i,1},j-1)
                            end
                        end
                    end
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                else
                    fprintf('Messed up\n')
                end
            else
                fprintf('Found a FET or Diode that wasn''t a FET or Diode\n Don''t panic\n')
            end
            
        end
        
    end
end

% Mischief Managed
clear I_solemnly_swear_that_I_am_up_to_no_good

end % That's all Folks
