function [pass] = RunTestCase(filename,converter,Check)

%% Test Cases
% This code runs a test case of AURA and compares the RMS value of the
% result to a goal end value and shows the times that were used to
% complete the sequence

% Might eventually make a function to determine the test case wanted
% or to run all of them to run a final check

load(converter);

parse = NetListParse();
parse.initialize(filename);
parse.ABCD();

top = SMPStopology();
top.Parser = parse;

conv.Topology = top;

simulator = SMPSim();

print = 0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
switch selection
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'DAB'
        Assignment = tic;
        filename = 'DAB_Resistors_Cap.net';
        parse = NetListParse();
        parse.initialize(filename);
        parse.ABCD();
        
        top = SMPStopology();
        top.Parser = parse;
        
        conv = SMPSconverter();
        conv.Topology = top;
        
        simulator = SMPSim();
        
        Vg = 48;
        L3 = 1e-6;
        L2 = 1296e-6;
        L1 = 76e-6;
        C1 = (4*100+680)*10^-6; %Cout
        C2 = 100*10^-6;
        fs = 0.2e6;
        Ts = 1/fs;
        V = 1.2;
        Io = 10; % was 1
        M1_C = 110e-12; % CHS
        M2_C = 110e-12; % LHS
        M3_C = 110e-12; % CHS
        M4_C = 110e-12; % LHS
        M5_C = 1620e-12; % CHS
        M6_C = 1620e-12; % LHS
        M7_C = 1620e-12; % CHS
        M8_C = 1620e-12; % LHS
        D1_C = 1620e-12; % LHS
        
        R3 = 0.001;
        
        R2 = 4.57535; % the inductor resistance % 1 ohm on the primary 1Ohm on the secondary
        dt = Ts/1000;%5e-10;
        
        Order = [1 2 3 4 5 6 7 8]; % The order that the states must go in after being parsed
        
        chooses = 9;
        switch chooses
            
            case 1
                PS = 400e-9;
                primary_dead = 50e-9;
                secondary_dead = 13.33e-9;
                Power = (Ts/2)-PS-primary_dead-secondary_dead;
                R1 = 0.141;
                
            case 6
                PS = 250e-9;
                primary_dead = 110e-9;
                secondary_dead = 13.33e-9;
                Power = (Ts/2)-PS-primary_dead-secondary_dead;
                R1 = 0.212955;
                
            case 9
                PS = 410e-9;
                primary_dead = 86.66e-9;
                secondary_dead = 13.33e-9;
                Power = (Ts/2)-PS-primary_dead-secondary_dead;
                R1 = 0.16;
                
            case 12
                PS = 620e-9;
                primary_dead = 86.66e-9;
                secondary_dead = 13.33e-9;
                Power = (Ts/2)-PS-primary_dead-secondary_dead;
                R1 = 0.1277;
        end
        
        ts = [primary_dead PS secondary_dead Power primary_dead PS secondary_dead Power ];
        
        % This is the the input voltage and the all of the body diode forward
        % voltages
        u = [Vg 1 1 1 1 1 1 1 1]';
        
        TestparseWaveform = false;
        
        ON = 1;
        OFF = 0;
        
        
        SW_OFF = ones(1,8).*10000000;
        
        SW_ON = [0.05 0.05 0.05 0.05 0.0015 0.0015 0.0015 0.0015];
        
        SW = [SW_OFF;SW_ON;SW_ON];
        
        Binary_for_DAB = [
            
        OFF OFF OFF OFF ON OFF OFF ON %primary sw
        OFF ON ON OFF ON OFF OFF ON % phase shift
        OFF ON ON OFF OFF OFF OFF OFF % secondary sw
        OFF ON ON OFF OFF ON ON OFF % Reverse power
        OFF OFF OFF OFF OFF ON ON OFF % primary sw
        ON OFF OFF ON OFF ON ON OFF % phase shift
        ON OFF OFF ON OFF OFF OFF OFF % secondary sw
        ON OFF OFF ON ON OFF OFF ON]; % POWER
    
    
    Numerical_Components = {'V1' Vg
        'C1' C1
        'C2' C2
        'L1' L1
        'L2' L2
        'L3' L3
        'M1_C' M1_C
        'M2_C' M2_C
        'M3_C' M3_C
        'M4_C' M4_C
        'M5_C' M5_C
        'M6_C' M6_C
        'M7_C' M7_C
        'M8_C' M8_C
        'R1' R1
        'R2' R2
        'R3' R3 };
    
    
    Switch_Resistors = {'M1_R'
        'M2_R'
        'M3_R'
        'M4_R'
        'M5_R'
        'M6_R'
        'M7_R'
        'M8_R'};
    
    
    THE_KEY = [
        33.8525
        33.8525
        0.9507
        0.9507
        0.9507
        0.0021
        0.2748
        33.8525
        33.8525
        0.9507
        1.3229];
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'Ind_Dickson'
        
        Assignment = tic;
        filename = 'Induct_Load_Dickson.net';
        parse = NetListParse();
        parse.initialize(filename);
        parse.ABCD();
        
        top = SMPStopology();
        top.Parser = parse;
        
        conv = SMPSconverter();
        conv.Topology = top;
        
        simulator = SMPSim();
        
        
        Vg = 48;
        Iload = 5;
        fs = 1e6;
        Ts = 1/fs;
        dt = Ts/100;
        L1 = 500e-9;
        C8 = 10e-6;
        r_on = 4e-3;
        Cds = 710e-12;
        Cx = 2e-6;
        Cx_ESR = 4e-3;
        [M1_R,M2_R,M3_R,M4_R,M5_R,M6_R,M7_R,M8_R,M9_R,M10_R,M11_R,M12_R] = deal(r_on);
        [M1_C,M2_C,M3_C,M4_C,M5_C,M6_C,M7_C,M8_C,M9_C,M10_C,M11_C,M12_C] = deal(Cds);
        [C1,C2,C3,C4,C5,C6,C7] = deal(Cx);
        [R1,R2,R3,R4,R5,R6,R7,R8] = deal(Cx_ESR);
        
        
        u = [Vg  1 1 1 1 1 1 1 1 1 1 1 1 Iload]';
        Order  = [1 2 3 4];
        ts = [Ts*.5-dt dt Ts*.5-dt dt]; % The inital guess of time intervals
        
        
        
        ON = 1;
        OFF = 0;
        
        
        % Binary_for_DAB = [
        % OFF ON OFF ON OFF ON OFF ON ON OFF OFF ON
        % ON OFF ON OFF ON OFF ON OFF OFF ON ON OFF
        %      ];
        
        Binary_for_DAB = [
            OFF ON OFF ON OFF ON OFF ON ON OFF OFF ON
            OFF OFF OFF OFF OFF OFF OFF OFF OFF OFF OFF OFF
            ON OFF ON OFF ON OFF ON OFF OFF ON ON OFF
            OFF OFF OFF OFF OFF OFF OFF OFF OFF OFF OFF OFF
            ];
        
        SW_OFF = ones(1,12).*10000000;
        
        SW_ON = [M1_R,M2_R,M3_R,M4_R,M5_R,M6_R,M7_R,M8_R,M9_R,M10_R,M11_R,M12_R];
        
        SW = [SW_OFF;SW_ON];
        
        Numerical_Components = {'V1' Vg
            'C1' C1
            'C2' C2
            'C3' C3
            'C4' C4
            'C5' C5
            'C6' C6
            'C7' C7
            'C8' C8
            'L1' L1
            'M1_C' M1_C
            'M2_C' M2_C
            'M3_C' M3_C
            'M4_C' M4_C
            'M5_C' M5_C
            'M6_C' M6_C
            'M7_C' M7_C
            'M8_C' M8_C
            'M9_C' M9_C
            'M10_C' M10_C
            'M11_C' M11_C
            'M12_C' M12_C
            'R1' R1
            'R2' R2
            'R3' R3
            'R4' R4
            'R5' R5
            'R6' R6
            'R7' R7
            'R8' R8};
        
        Switch_Resistors = {'M1_R'
            'M2_R'
            'M3_R'
            'M4_R'
            'M5_R'
            'M6_R'
            'M7_R'
            'M8_R'
            'M9_R'
            'M10_R'
            'M11_R'
            'M12_R'};
        
        THE_KEY = [
            4.2401
            8.4303
            8.5074
            8.5074
            42.0640
            36.0787
            30.0397
            24.0001
            8.5074
            8.5074
            8.4303
            4.2404
            17.9611
            11.9216
            5.9377
            5.8051
            4.1757
            4.1795
            5.0001
            4.1760
            4.1791];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 'MR_Buck'
        
        Assignment = tic;
        filename = 'MR_Buck.net';
        parse = NetListParse();
        parse.initialize(filename);
        parse.ABCD();
        
        top = SMPStopology();
        top.Parser = parse;
        
        conv = SMPSconverter();
        conv.Topology = top;
        
        simulator = SMPSim();
        
        Vg = 12;
        L1 = 1e-6; %L
        C1 = 1*10^-6; %Cout
        L2 = 0.01e-9; % Resonate inductor
        fs = 1e6;
        Ts = 1/fs;
        V = 3;
        Io = 0.1; % was 1
        M1_C = 1.5e-9; % CHS
        M2_C = 1.5e-9; % LHS

        M1_R_ON = 0.002; % ronHS
        M2_R_ON = 0.002; % ronLS

        Order = [1 2]; % The order that the states must go in after being parsed
        
        D = 5/12;
        %dead = 0.001/fs;
        dead = 0.01/fs;
        % ts = [25e-9 25e-9 25e-9 25e-9];
        ts = [Ts/4 3*Ts/4];
        u = [Vg 1 1 Io]';
        
        
        TestparseWaveform = false;
        
        ON = 1;
        OFF = 0;
        
        
        SW_OFF = ones(1,2).*10000000;
        
        SW_ON = [M1_R_ON M2_R_ON];
        
        SW = [SW_OFF; SW_ON; SW_ON];
        
          Numerical_Components = {
            'C1' C1
            'L1' L1
            'L2' L2
            'M1_C' M1_C
            'M2_C' M2_C
            };
        
        
        Binary_for_DAB = [
            ON OFF
            OFF OFF];
        
        
        Switch_Resistors = {'M1_R'
            'M2_R'};
        
        THE_KEY = [
        11.1089
        2.4463
        6.2030
        0.7540
        7.9659];
        
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    case 'AC Fly'
        
        Assignment = tic;
        filename = 'Flyback_new.net';
        parse = NetListParse();
        parse.initialize(filename);
        parse.ABCD();
        
        top = SMPStopology();
        top.Parser = parse;
        
        conv = SMPSconverter();
        conv.Topology = top;
        
        simulator = SMPSim();
        
        Vg = 5;
        
        fs = 1e6;
        Ts = 1/fs;
        dt = 0.02/fs;
        L1 = 1e-3; % Primary turns
        L2 = 16e-3; % Secondary turns
        L3 = 0.947e-6;  % Magnetizing inductance
        r_on = 16e-3;
        Cds = 150e-12;
        L4 = 50e-9; % Resonate indcutor
        C2 = 112e-9; % Resonate Cap
        C1 = 10e-6; % Output Cap
        R1 = 133.3333;
        [M1_R,M2_R,M3_R] = deal(r_on);
        [M1_C,M2_C,M3_C] = deal(Cds);
        
        M3_C_Resist = 10000;
        M2_C_Resist = 10000;
        M1_C_Resist = 10000;
       
        
        u = [Vg 1 1 1]';
        Order  = [1 2 3 4 5 6];
        ts = [Ts*.53-dt dt 70e-9 Ts*.47-dt-70e-9-50e-9 50e-9  dt]; % The inital guess of time intervals
        
        Numerical_Components = {'C1' C1
            'C2' C2
            'L1' L1
            'L2' L2
            'L3' L3
            'L4' L4
            'M1_C' M1_C
            'M2_C' M2_C
            'M3_C' M3_C
            'R1' R1
            'M3_C_Resist' M3_C_Resist
            'M2_C_Resist' M2_C_Resist
            'M1_C_Resist' M1_C_Resist
            };
        
        Switch_Resistors = {'M1_R'
            'M2_R'
            'M3_R'};
        
        ON = 1;
        OFF = 0;
        
        Binary_for_DAB = [
            ON OFF OFF
            OFF OFF OFF
            OFF ON OFF
            OFF ON ON 
            OFF ON OFF
            OFF OFF OFF
            
            ];
        
        SW_OFF = ones(1,3).*10000000;
        
        SW_ON = [M1_R,M2_R,M3_R];
        
        SW = [SW_OFF;SW_ON;SW_ON];
        
        
    otherwise
        fprintf('Pick a test case that actually exists please\n') % Well you should
        return
end

%}

ts=conv.ts;
u = conv.u ;
Order = conv.order;
Numerical_Components = conv.Element_Properties ;
Switch_Resistors = conv.Switch_Resistors;
SW = conv.Switch_Resistor_Values ;
Binary_for_DAB = conv.Switch_Sequence;

for i = 1:1:size(Numerical_Components,1)
    eval([Numerical_Components{i,1} '=' 'Numerical_Components{i,2};'])
end



%{
% Switch Resistors Contains the same order of resistors as was given
% in the Binary matrix provided by the user to determine when states
% are on or off
for i = 1:1:size(Switch_Resistors,1)
    eval([Switch_Resistors{i} '=' 'out{i}']);
end
%}



A = parse.Asym;
B = parse.Bsym;
C = parse.Csym;
D = parse.Dsym;

SortedTree = parse.SortedTree;
SortedCoTree = parse.SortedCoTree;

if isempty(A)
    for k = 1:1:size(Binary_for_DAB,1)
        
        out = {};
        
        for j = 1:1:size(Binary_for_DAB,2)
            out{j} = SW(Binary_for_DAB(k,j)+1,j);
        end
        for i = 1:1:size(Switch_Resistors,1)
            eval([Switch_Resistors{i} '=' 'out{i};'])
        end
        
        HtempAB(:,:,k) = eval(parse.HtempAB(:,:,1));
        HtempCD(:,:,k) = eval(parse.HtempCD(:,:,1));
        dependsAB(:,:,k) = eval(parse.dependsAB(:,:,1));
        savedCD(:,:,k) = eval(parse.savedCD(:,:,1));
        for j = 1:1:size(parse.DependentNames(:,1),1)
            DependentNames(j,k) = eval(parse.DependentNames{j,1});
        end
        for j = 1:1:size(parse.OutputNames(:,1),1)
            OutputNames(j,k) = eval(parse.OutputNames{j,1});
        end
    end
    for k = 1:1:size(HtempAB,3)
        [A,B,C,D] = parse.loopfixAB_large(HtempAB(:,:,k),dependsAB(:,:,k),OutputNames(:,k),DependentNames(:,k));
        [C,D] = parse.loopfixCD_large(B,C,D,HtempCD(:,:,k),savedCD(:,:,k),DependentNames(:,k),SortedTree(:,:,1),SortedCoTree(:,:,1));
        parse.Anum(:,:,k)=A;
        parse.Bnum(:,:,k)=B;
        parse.Cnum(:,:,k)=C;
        parse.Dnum(:,:,k)=D;
        [parse.eigA(:,k)] = eig(parse.Anum(:,:,k));
    end
    
    % Set all diode forward voltages to be off
    B = parse.Bnum;
    B(:,contains(parse.ConstantNames,'VF'),:)=0;
    parse.Bnum = B;
    D = parse.Dnum;
    D(:,contains(parse.ConstantNames,'VF'),:)=0;
    parse.Dnum = D;
    
elseif ~isempty(parse.Anum)
    fprintf('Confirm Plecs used');
else
    for k = 1:1:size(Binary_for_DAB,1)
        
        out = {};
        
        for j = 1:1:size(Binary_for_DAB,2)
            out{j} = SW(Binary_for_DAB(k,j)+1,j);
        end
        
        for i = 1:1:size(Switch_Resistors,1)
            eval([Switch_Resistors{i} '=' 'out{i};']);
        end
        
        parse.Anum(:,:,k) = eval(A(:,:,1));
        parse.Bnum(:,:,k) = eval(B(:,:,1));
        parse.Cnum(:,:,k) = eval(C(:,:,1));
        parse.Dnum(:,:,k) = eval(D(:,:,1));
        [parse.eigA(:,k)] = eig(parse.Anum(:,:,k));
    end
    % Set all diode forward voltages to be off
    B = parse.Bnum;
    B(:,contains(parse.ConstantNames,'VF'),:)=0;
    parse.Bnum = B;
    D = parse.Dnum;
    D(:,contains(parse.ConstantNames,'VF'),:)=0;
    parse.Dnum = D;
end

simulator.loadTestConverter2(conv);
simulator.eigA = parse.eigA;
simulator.binary = Binary_for_DAB;
Xss = simulator.SS_Soln();
Xss_Aug=simulator.SS_Soln_Aug();

%% Reconstruction of Dependent variables
parse.StateVarIndex();
simulator.CorrectXs();


for i = 1:1:length(parse.StateNumbers)
    if strcmp(parse.OutputNamesCD{parse.StateNumbers(i),1}(1,end),'A')
        top.stateLabels(end+1,1) = strcat('I_{', parse.StateNames(i,1),'} (A)');
        top.stateLabels_Opp(end+1,1) = strcat('V_{', parse.StateNames(i,1),'} (V)');
    else
        top.stateLabels(end+1,1) = strcat(parse.OutputNamesCD{parse.StateNumbers(i),1}(1,end),'_{', parse.StateNames(i,1),'} (V)');
        top.stateLabels_Opp(end+1,1) = strcat('I_{', parse.StateNames(i,1),'} (A)');
    end
end


parse.find_diode_new(Order,Binary_for_DAB);
iterations = 100;
simulator.Three_tier_diode_correct(iterations,print)

[~, ~, y] = simulator.SS_WF_Reconstruct();

StateNumbers = parse.StateNumbers;

State_RMS = rms(y(StateNumbers,:),2);




difference = State_RMS-THE_KEY;

if print
    fprintf('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n')
    fprintf('Test_Case %s Results\n',selection)
    fprintf('------------------------------\n')
    fprintf('%15s %12s \n','State Variable','Difference')
    for i  = 1:length(difference)
        fprintf('%15s %12.8f \n',top.stateLabels{i},difference(i))
    end
    fprintf('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n')
end

if sum(difference>0.5)>0
    pass = false;
    fprintf('Better luck next time')
else
    pass = true;
end


return















