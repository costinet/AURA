%use ghostscript to make pngs from pdf pages
gsloc = '"C:\Program Files\gs\gs9.52\bin\gswin64.exe"';
dldir = 'C:\Users\dcostine\Downloads\';
fn = 'EPC2023_datasheet.pdf';

status = system([gsloc ' -sDEVICE=pngalpha -r300 -o file-%03d.png ' dldir fn]);
%"C:\Program Files\gs\gs9.52\bin\gswin64.exe" -sDEVICE=pngalpha -o file-%03d.png -r144 EPC2023_datasheet.pdf

% C:\Users\dcostine\Dropbox\UTK\Research\AURA\Ideas\PlotDigitizer\file-001.png

