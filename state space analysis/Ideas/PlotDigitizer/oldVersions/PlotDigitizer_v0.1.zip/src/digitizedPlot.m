classdef digitizedPlot < handle
    %DIGITIZEDPLOT data storage for digitized image plot
    %   Detailed explanation goes here
    
    properties
        plotData    % x-y data extracted from plot
        imgData     % in pixels from upper-left of plot area
        normData    % 0-1, in distance from origin
        
        axes        % [Xo Xm Yo Ym] -- limits of the plot
        imgAxes     % [colLeft colRight rowBottom rowTop] -- location of plot on image
        
        img         % RGB data of full plot image
        
        logAxes     % [x y], log scale boolean
        normAxes    % [x y], normalized boolean
        
        axisLabels  % string axislabel
        dataLabels  % labels for individual traces
        SIUnits
        
        callingApp
    end
    
    methods
        function obj = digitizedPlot(app)
            %obj = digitizedPlot(app) Construct an instance of this class
            %   Detailed explanation goes here
            obj.callingApp = app;
        end
        
        function convert(obj, dir)
            %convert(obj, dir) Summary of this method goes here
            %   Detailed explanation goes here
            if nargin == 1
                dir = -1;
            end
            if (dir==1) || (~isempty(obj.imgData) && ~isempty(obj.imgAxes) &&...
                    ~isempty(obj.axes) && isempty(obj.plotData))
               %% Image data and axes calibration data given; create plot data
               for i = 1:length(obj.imgData)
                  ximgdist = obj.imgData{i}(:,1) - obj.imgAxes.colLeft;
                  ximgspan = obj.imgAxes.colRight -  obj.imgAxes.colLeft;
                  obj.normData{i}(:,1) = ximgdist/ximgspan;
                  
                  yimgdist = obj.imgAxes.rowBottom - obj.imgData{i}(:,2);
                  yimgspan = obj.imgAxes.rowBottom -  obj.imgAxes.rowTop;
                  obj.normData{i}(:,2) = yimgdist/yimgspan;
                  
                  xspan = obj.axes.Xm - obj.axes.Xo;
                  yspan = obj.axes.Ym - obj.axes.Yo;
                  obj.plotData{i}(:,1) = obj.axes.Xo + obj.normData{i}(:,1)*xspan;
                  obj.plotData{i}(:,2) = obj.axes.Yo + obj.normData{i}(:,2)*yspan;
               end
               
            elseif (dir == 2) || (~isempty(obj.plotData) && ~isempty(obj.imgAxes) && ...
                    ~isempty(obj.axes) && isempty(obj.imgData))
                %% Plot data (e.g. grabit) and axes calibration data given; create image data
                for i = 1:length(obj.plotData)
                    xdist = obj.plotData{i}(:,1) - obj.axes.Xo;
                    xspan = obj.axes.Xm - obj.axes.Xo;
                    obj.normData{i}(:,1) = xdist/xspan;
                    
                    ydist = obj.plotData{i}(:,2) - obj.axes.Yo;
                    yspan = obj.axes.Ym - obj.axes.Yo;
                    obj.normData{i}(:,2) = ydist/yspan;
                    
                    obj.imgData{i}(:,1) = obj.normData{i}(:,1)* ...
                        (obj.imgAxes.colRight - obj.imgAxes.colLeft) + obj.imgAxes.colLeft;
                    obj.imgData{i}(:,2) = (1-obj.normData{i}(:,2))* ...
                        (obj.imgAxes.rowBottom - obj.imgAxes.rowTop) + obj.imgAxes.rowTop;
                end
            else
                warning('Insufficient data stored to do any conversion');
                return
            end
        end
        
        function loadGrabitData(obj, handle)
            %loadGrabitData(obj, handle) Summary of this method goes here
            %   Detailed explanation goes here
            obj.img = handle.I;
            
            obj.axes.Xo = handle.CalibVals.Xo;
            obj.axes.Xm = handle.CalibVals.Xm;
            obj.axes.Yo = handle.CalibVals.Yo;
            obj.axes.Ym = handle.CalibVals.Ym;
            
            obj.imgAxes.colLeft = handle.CalibVals.Xxo;
            obj.imgAxes.colRight = handle.CalibVals.Xxo + ...
                handle.CalibVals.e1(1)*(handle.CalibVals.Xm-handle.CalibVals.Xo);
            obj.imgAxes.rowBottom = handle.CalibVals.Yyo;
            obj.imgAxes.rowTop = handle.CalibVals.Yyo + ...
                handle.CalibVals.e2(2)*(handle.CalibVals.Ym-handle.CalibVals.Yo);
            
            traces = fieldnames(handle.savedVars);
            for i = 1:length(traces)
                data = eval(['handle.savedVars.' traces{i}]);
                obj.plotData{i} = data;              
            end
            obj.dataLabels = traces;
            obj.loadAppData();
            obj.convert();
        end
        
        function loadAppData(obj)
            %loadAppData(obj) Summary of this method goes here
            %   Detailed explanation goes here
            obj.logAxes = [obj.callingApp.LogarithmicXaxisCheckBox.Value, obj.callingApp.LogarithmicYaxisCheckBox.Value];
            obj.normAxes = [obj.callingApp.NormalizedXaxisCheckBox.Value, obj.callingApp.NormalizedYaxisCheckBox.Value];
            obj.axisLabels = {obj.callingApp.XaxisDropDown.Value, obj.callingApp.YaxisDropDown.Value};
            obj.SIUnits = {obj.callingApp.XSIprefixDropDown.Value, obj.callingApp.YSIprefixDropDown.Value};
            
            if isempty(obj.img)
                obj.img = obj.callingApp.plotOrigImage;
            end
            
            if isempty(obj.axes)
            	obj.axes.Xo = obj.callingApp.MinXValueEditField.Value;
                obj.axes.Xm = obj.callingApp.MaxXValueEditField.Value;
                obj.axes.Yo = obj.callingApp.MinYValueEditField.Value;
                obj.axes.Ym = obj.callingApp.MaxYValueEditField.Value;
            end
            
            if isempty(obj.imgAxes)
                obj.imgAxes.colLeft = obj.callingApp.imgAxes(1);
                obj.imgAxes.colRight = obj.callingApp.imgAxes(2);
                obj.imgAxes.rowBottom = obj.callingApp.imgAxes(3);
                obj.imgAxes.rowTop = obj.callingApp.imgAxes(4);
            end
            
            if isempty(obj.dataLabels)
                if ~isempty(obj.imgData)
                    len = length(obj.imgData);
                elseif ~isempty(obj.plotData)
                    len = length(obj.plotData);
                else
                    return
                end
                obj.dataLabels = cellstr([repmat(['Y'],len,1), num2str([1:len]')]);
            end
        end
        
        function loadAutoColorDigitizedData(obj, ximg, traces)
            %loadAutoColorDigitizedData(obj, ximg, traces) Summary of this method goes here
            %   Detailed explanation goes here
            obj.loadAppData();
            for i = 1:size(traces,2)
                x = ximg + obj.imgAxes.colLeft;
                y = traces(:,i) + obj.imgAxes.rowTop;
                
                obj.imgData{i} = [x(~isnan(y)), y(~isnan(y))];
            end
            obj.loadAppData();
            obj.convert();
        end
        
        function plotDigitizedData(obj, axes)
            %plotDigitizedData(obj, axes) Summary of this method goes here
            %   Detailed explanation goes here
            hold(axes, 'off');
            imshow(obj.img, 'Parent', axes);
            hold(axes, 'on');
            
            for i = 1:length(obj.imgData)
                lines(i) = plot(axes, obj.imgData{i}(:,1), obj.imgData{i}(:,2), ':', 'LineWidth', 3); 
            end
            
            plot(axes, [obj.imgAxes.colLeft obj.imgAxes.colLeft], [obj.imgAxes.rowBottom obj.imgAxes.rowTop],'-r', 'LineWidth', 3);
            plot(axes, [obj.imgAxes.colRight obj.imgAxes.colRight], [obj.imgAxes.rowBottom obj.imgAxes.rowTop],'-r', 'LineWidth', 3);
            plot(axes, [obj.imgAxes.colLeft obj.imgAxes.colRight], [obj.imgAxes.rowBottom obj.imgAxes.rowBottom],'-r', 'LineWidth', 3);
            plot(axes, [obj.imgAxes.colLeft obj.imgAxes.colRight], [obj.imgAxes.rowTop obj.imgAxes.rowTop],'-r', 'LineWidth', 3);
            legend(axes, lines, obj.dataLabels);
            
            axes.XLim = [0 size(obj.img,2)];
            axes.YLim = [0 size(obj.img,1)];
        end
    end
end

