function  pdfSelectionRectMoved(rect,event)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    rect.callingApp.pdfSelectionRectMoved(rect);
%     src.identifyPlot()
end

