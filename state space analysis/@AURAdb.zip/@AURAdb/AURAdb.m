classdef AURAdb < handle
    %AURAdb is a collection of databases
    
    properties (SetAccess = immutable, GetAccess = public)
        transistors
        inductors
        capacitors
        cores
        wires
    end
    
    methods
        function obj = AURAdb()
            obj.transistors = 
            obj.inductors = 
            obj.capacitors = 
            obj.cores = 
            obj.wires = 
        end
        
        function sync(obj)
            obj.transistors.sync();
            obj.inductors.sync();
            obj.capacitors.sync();
        end
    end
end

