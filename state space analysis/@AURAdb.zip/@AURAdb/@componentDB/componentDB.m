classdef componentDB < handle
    %componentDB is a template for individual component databases
    
    properties (SetAccess = private, GetAccess = private)
        tableProps
        addTabProps
        graphProps
    end
    
    properties (Hidden, Transient, Access = protected, Constant)
        %SIkeys = {'f','p','n','u','m','1','k','M','G','T','P'};  
            % USE keys(SIprefixes)
        SIprefixes = containers.Map({'f','p','n','u','m','1','k','M','G','T','P'}, ...
                                    [1E-15 1E-12 1E-9 1E-6 1E-3 1E0 1E3 1E6 1E9 1E12 1E15]);        
    end
    
    properties (Hidden, Transient, Abstract, Constant)
        componentType       
%             defaultUnits
%             tableParams
%             knownParams
%             knownTypes
%             knownMaterials
    end
    
    methods (Abstract)
        [table, addlTable, graph] = json(obj)
        sync(obj)
        add(obj, item)
        subTable(obj, varargin) % Return a nicely-formatted table with searchable parameters
    end
    
    methods
        function obj = componentDB()
            %UNTITLED Construct an instance of this class
            %   Detailed explanation goes here
            obj.componentType = component();
        end
        

    end
end

