classdef transistorDB < componentDB
    %componentDB is a template for individual component databases
    
    properties (Hidden, Transient, Abstract, Constant)
        tableParams = {}
        defaultUnits = {}
        knownParams = {}
        knownTypes = {}
        knownMaterials = {'Si', 'GaN', 'SiC', 'GaAs'}
    end
    
    methods 
        sync(obj)
        add(obj, item)
        subTable(obj, varargin)
    end
    
    methods
        function obj = untitled(inputArg1,inputArg2)
            %UNTITLED Construct an instance of this class
            %   Detailed explanation goes here
            obj.Property1 = inputArg1 + inputArg2;
        end
        

    end
end

